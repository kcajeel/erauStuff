/*
Class: 
Name: 
Date: 
Purpose: 
Attributes: 
	
Methods: 
	
*/
public class GlassWallTile extends GenericTile{
	public void enterAction(){
		System.out.println("Glass Wall Tile entered. ");
		
	}
	public void exitAction(){
		System.out.println("Glass Wall Tile exited. ");
	}
	public void specialAction(){}		
}