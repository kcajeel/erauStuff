public class SlowCar extends GenericCar{
	public SlowCar(double distance, double lane, GenericDriver driver){
		super(distance, lane, driver, getRandom(2,4), getRandom(2,4),(int)getRandom(60,70));
	}
}